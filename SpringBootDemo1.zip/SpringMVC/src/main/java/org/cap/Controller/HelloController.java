package org.cap.Controller;

import org.springframework.stereotype.Controller;

@Controller
public class HelloController {

}
