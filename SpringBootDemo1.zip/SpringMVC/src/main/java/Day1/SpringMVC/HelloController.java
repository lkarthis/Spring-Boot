package Day1.SpringMVC;

import org.springframework.stereotype.Controller;

@Controller
public class HelloController {

}
