class Auto {
    private int maxSpeed;
    float weight;
    //constructor with parameters
    public Auto(int maxSpeed, float Weight) {
        //shadowing
        //Assignment to itself warning
        maxSpeed = maxSpeed;
        weight = Weight;
    }
    public void setMaxSpeed(int maxSpeed) {
        //shadowing
        //Assignment to itself warning
        maxSpeed = maxSpeed;
    }
    public int getMaxSpeed() {
        return this.maxSpeed;
    }
}
 
public class Main {
 
    public static void main(String[] args) {
        Auto a = new Auto(180, 2000);
        System.out.println(a.getMaxSpeed());
        a.setMaxSpeed(200);
        System.out.println(a.getMaxSpeed());
    }
}

