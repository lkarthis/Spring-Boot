
public class StringDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = null; //new String("test");
		String s1 = new String("test");
		String t = "test";
				System.out.println(" s: " + s + " t: " + t);
				System.out.println(" s==t " + (s==t) );
				System.out.println("s.equeals(t) : " + s.equals(t));
				System.out.println("s1==s: " + (s1==s));
	}

}
